<!DOCTYPE html>
<html lang="ar" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<title>Flashlight – world’s most powerful tactical flashlight!</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="./index_files/reset.css">
    <link rel="stylesheet" href="./index_files/form.css">
    <link rel="stylesheet" href="./index_files/style.css">
    <link rel="stylesheet" href="./index_files/media.css">
<script>
  (function() {
    var ta = document.createElement('script'); ta.type = 'text/javascript'; ta.async = true;
    ta.src = 'https://analytics.tiktok.com/i18n/pixel/sdk.js?sdkid=BTGD1IJQ55EMJL0L2LIG';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(ta, s);
  })();
</script>
  
  
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-136677299-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-136677299-1');
</script>

		<script src="./index_files/jquery.min.js"></script>

    <script type="text/javascript" src="./index_files/functions.js"></script>
    <script src="./index_files/jquery.inputmask.bundle.min.js"></script>
<script type="text/javascript">!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version="2.0";n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","570112720241474");fbq("track","PageView");</script><link type="text/css" rel="stylesheet" charset="UTF-8" href="./index_files/translateelement.css"></head>
<body>
	<header class="header">
        <div class="container flex">
            <img src="./index_files/header-img.png" class="header-img">
            <div class="right"><a href="#form2" class="btn btnh">طلب الان   </a>
                <div class="prices">
                  <span class="new-price"><span class="adfh-new-price">169</span> <span class="adfh-currency">SAR</span></span>
                  <span class="old-price"><span class="adfh-old-price">285</span> <span class="adfh-currency">SAR</span></span>
              </div></div>
          </div>
      </header>
      <section class="s1">
          <div class="container">
              <img src="./index_files/offer.png" alt="">
              <h1 class="main-title">أقوى كشاف في العالم!</h1>
              <p style="    text-align: center;
    color: #fff;">شهادة المطابقة ورقم هاتف الاتصال موجودان في أسفل الصفحة!</p>
              <img src="./index_files/case.png" alt="">
              <div class="form_wrap">
                  <div id="form1" class="form_block">
                    <span class="sp white">الخصم <span class="adfh-discount">40</span>%!</span>
                    <span class="sp white">الكمية محدودة</span>
                    <span class="sp white old-price">السعر القديم: <span class="adfh-old-price">285</span> <span class="adfh-currency">SAR</span></span>
                    <span class="sp new-price">السعر الجديد: <span class="adfh-new-price">169</span> <span class="adfh-currency">SAR</span></span>
                    <span class="sp white">الوقت المتبقى للشراء:</span>
                    <div class="timer">
                        <div id="countdown" class="countdownHolder"></div>
                    </div>
                    <div class="form form-wrapper">
                        <form class="form" action="success.php" method="POST">
                            <input class="form-name name fio" name="name" placeholder="إسم" required="required" style="text-align: right;" minlength="2" maxlength="30">
                            <input class="form-phone phone tel" name="phone" placeholder="رقم الموبيل" required="" type="tel" style="text-align: right;">
                            <button name="button" class="form-btn" type="submit">اطلب الان   </button>
                        </form>
                    </div>
                </div>
            </div>
          </div>
      </section>
        <section class="s2">
            <div class="container">
                <div class="s2-border">
                    <img src="./index_files/s2-img.png" alt="">
                    <p>صغير وقوي</p>
                    <p>يدمج TM03 عنصرين رئيسيين: مصباح ومركم واحد فإنه توفر طاقة أكثر بكثير وسطوع يصل إلى 2800 لومن! العرض يشمل شاحن البطارية. عاكس OP عميق للغاية يزيد بشكل كبير من كفاءة الانعكاس ومسافة الشعاع والإضاءة مما يسمح للمستخدمين الرؤية لمسافات أكثر وبالراحة البصرية التامة.</p>
                </div>
                <div class="s2-border-bot">
                    <div class="s2-wrap flex">
                        <img src="./index_files/s2-img2.png" alt="">
                        <div class="wrap-text">
                            <p>ضربة على الفور بضوء فائق</p>
                            <p>اضغط مع الاستمرار على مفتاح Mode لتوفير ضوء يبلغ 2800 لومن يمكّنك من تحديد الشخص المهاجم وإيقافه مما يتيح لك المسافة  والوقت لأخذ القرار. إن الإضاءة القوية عالية التردد تجعل الكشاف مثاليا للدفاع عن النفس بأي ضوء وسيناريوهات أخرى.</p>
                            <div class="wrap-text">
                                <p>مشغّل بمركم واحد مخصص    </p>
                                <p>أثناء تشغيل الاضاءة اضغط على مفتاح الوضع للتنقل بين أربعة مستويات سطوع. جسم الكشاف مصنوع من سبائك الألمنيوم الصف كونه خفيفا وصغيرا. الفولاذ المقاوم للصدأ الحاد يحمي المقطع الأساسي من التلف.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
        <section class="s3">
            <div class="container">
                <img src="./index_files/s3-img.png" alt="">
                <p>أربعة مستويات لامعة للتطبيقات المختلفة</p>
                <p>أثناء تشغيل الاضاءة اضغط على مفتاح الوضع للتنقل بين أربعة مستويات سطوع. جسم الكشاف مصنوع من سبائك الألمنيوم الصف كونه خفيفا وصغيرا. الفولاذ المقاوم للصدأ الحاد يحمي المقطع الأساسي من التلف.</p>
                <img src="./index_files/s3-img2.png" alt="">
                <p>يتم توفير الكشاف مع الصندوق باللون الأخضر المقاوم للماء! مضاد للصدمات والتلف عند الوقوع من ارتفاع يصل إلى نصف متر.</p>
                <img src="./index_files/s3-img3.png" alt="">
            </div>
        </section>
        <section class="s4">
            <div class="contaienr">
                <img src="./index_files/s4-img.png" alt="">
                <img src="./index_files/s4-img2.png" alt="">
            </div>
        </section>
        <section class="s5">
            <div class="container">
                <div class="rew-block flex">
                    <img src="./index_files/rew1.png" alt="" class="rew-img">
                    <div class="rew-text">
                        <p class="auth">محمود</p>
                        <p class="feedback">يعمل بشكل مثالي وهو ألمع كشاف الذي واجهته على الإطلاق وبجودة تصميم عالية. يضيء مساحة أكثر بكثير من الاجهزة المماثلة الأكثر تكلفة. فعلا تجاوزت توقعاتي!</p>
                    </div>
                </div>
                <div class="rew-block flex">
                    <img src="./index_files/rew2.png" alt="" class="rew-img">
                    <div class="rew-text">
                        <p class="auth">طارق</p>
                        <p class="feedback">كشاف يدوي رهيب. لدي واحد لنفسي وطلبت واحد لأحد أفراد الأسرة! قوي وخفيف الوزن! بالتأكيد أوصي به للجميع!</p>
                    </div>
                </div>
                <div class="rew-block flex">
                    <img src="./index_files/rew3.png" alt="" class="rew-img">
                    <div class="rew-text">
                        <p class="auth">زياد</p>
                        <p class="feedback">إنه قوي وعالي الجودة ويوفر الاضاءة بشكل رائع بالنسبة لحجمه. سوف يثير إعجاب الأصدقاء (أو الغرباء). انه يضيء ليس فقط الفناء الخلفي بأكمله ولكن يضيء الفناء للجيران أيضا! شيء رائع بسعر معقول!</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="s6">
            <div class="container">
               <img src="./index_files/offer.png" alt="">
              <h1 class="main-title">أقوى كشاف في العالم!</h1>
              <img src="./index_files/case.png" alt="">
               <div class="form_wrap">
                  <div id="form2" class="form_block">
                    <span class="sp white">الخصم <span class="adfh-discount">40</span>%!</span>
                    <span class="sp white">الكمية محدودة</span>
                    <span class="sp white old-price">السعر القديم: <span class="adfh-old-price">285</span> <span class="adfh-currency">SAR</span></span>
                    <span class="sp new-price">السعر الجديد: <span class="adfh-new-price">169</span> <span class="adfh-currency">SAR</span></span>
                    <span class="sp white">الوقت المتبقى للشراء:</span>
                    <div class="timer">
                        <div id="countdown1" class="countdownHolder"></div>
                    </div>
                    <div class="form form-wrapper">
                        <form class="form orderformcdn" action="success.php" method="POST">
                            <input class="form-name name fio" name="name" placeholder="إسم" required="required" style="text-align: right;" minlength="2" maxlength="30">
                            <input class="form-phone phone tel" name="phone" placeholder="رقم الموبيل" required="" type="tel" style="text-align: right;">

                            <button name="button" class="form-btn" type="submit">اطلب الان    </button>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </section>

 <script type="text/javascript" src="./index_files/form-handler.js"></script>
    <script type="text/javascript">

    </script><div class="footer-info" style="padding: 20px 0; text-align: center; font-family: &#39;Arial&#39;, sans-serif; font-size: 14px;"><div class="footer-info__link">

<img src="2020-08-17 18.13.49.jpg" style="width: 10%">
        <p>XIWARE TECHNOLOGIES LTD.</p>
        <p>SCS110470191</p>
        <p>2nd Floor, Building#11, Zhucun, Guanlan</p>
        <p>tel:+86-755-27880691</p>
        <a href="http://safla.bqgism.com/privacy" target="_blank" style="color: #000; padding-right: 10px">Privacy Policy</a><a href="http://safla.bqgism.com/conditions" target="_blank" style="color: #000; padding-left: 10px">Terms &amp; Conditions</a></div></div>

		<div id="responseContainer"></div><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="./index_files/translate_24dp.png" width="20" height="20" alt="Google Переводчик"></div>
	</div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Исходный текст</h1></div>
		<div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links">
			<span class="activity-link">Предложить лучший вариант перевода</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div>

<div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div>
        <script>
	    function lockform(form){
	        // message - сообщение нетерпеливым
	        // imageBase64- сюда можно установить свою картинку в строке base64
	        var message = 'Please Wait!'; 
			var imageBase64 = 'R0lGODlhHgAeAPYAAIHM/7zk/5DS//L6/+z3/6Tf/7Tk/tzz/4bT/un3/6ng/2nJ/v7+//D6/3bO/6vd//b7/+Dy/9Lv/7jm/+H1/+75/5bZ/9ry/+74/fb6/eL0//T5/KDY/9Lt/3zQ/8br/2bB/9fx/w2n/Mzq/wCY/5nW/z66//L4/K7i/+j1/Ei+/3PN/+v4/+b1/7Pg/9nw//n8/vT7/5/d/8zr//T6/vr9//z+//3+/8Dm//z9/s/u/8Pp/vn9/vX8/8Lp/3DF/4zR/9nv/0q9/W7L//X6/UCy//P4/J/Z/0q+/xyt/LPk/8/r/+n2/BCe/1PC//n9//D5//f8/8bo/9/y/43W/+b2/9Ds//v9/nnJ/yCl/+v2/Kbb/yuy/F/G/1bD//X7//n8/7zn//r8/svs/2C//4fU//H5/czt//j8//3+/uX2/2LH/zu4/d/0/zCr/9bu/8Pq//j8/rDf/9Tw/6/j//X7/lC4/7nj/9zx/4HS/+T1/1nD/fL5/Zjb//f7/f///yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ1dWlkOjVEMjA4OTI0OTNCRkRCMTE5MTRBODU5MEQzMTUwOEM4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNCNDE4NjI0OUI5RjExRTE4MTc4RDRBQTc2OURFNTk5IiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNCNDE4NjIzOUI5RjExRTE4MTc4RDRBQTc2OURFNTk5IiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDUzUgTWFjaW50b3NoIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTIzNjE2MUUwRjIwNjgxMThDMTREREU0QTUwMUM5NEYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OTEzNjE2MUUwRjIwNjgxMThDMTREREU0QTUwMUM5NEYiLz4gPGRjOnRpdGxlPiA8cmRmOkFsdD4gPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij5URkhPTUVQQUdFX2xvYWRzY3JlZW4yPC9yZGY6bGk+IDwvcmRmOkFsdD4gPC9kYzp0aXRsZT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQFAAB/ACwAAAAAHgAeAAAH/4B/goOEhCQkhYmKg0REhYeFIGSLhRknJxmGiIM/IiI/lIRGJ0aahEUiSaGEG5cbg5CCZJ6Tq4OjpYKxf0kiXKEYlZe5bm6Cdp5YhcqDKSlarEavkUl2hCAmJoRMzs+2hD9C2UiFWt1M339I2SagiRjmKenZZEDAwd9YAOn8i2r///oJKkGQ4J8QCBO+6bdHhUOHey4kRHihX5eHDr0I3MjRVoeF+exRerNkxIhvAkCA+CEgURArJkd0SIdFJQhmgoLE7ICnn4AfNge9GGEFpCADKHwkorKCCiEgP9wtCoMiqSAOWwQxXXGknxwUEwTJMSjIw4o8/KiiGCOW7J8SKyhWWEhXNcygsSUI5Vnh4RsOFHQI4SW0ZYWDdEoFuxVUpuOfACU4pAsEACH5BAUAAH8ALAAAAAAeAB4AAAf/gH+Cg4SEJyeFiYqDGBiFh4V2douFZikpjoOQgyAkJCCUhEwpTIaIg1kkTaGEWpdamqd/dp6TrIOjpYKbf00kWaFthRiXuhsbgkWeoITMgiEhB61MmYRkTUWEdiIihNAhb8K3g9vcSYUH3xfjf0ncIraFGukh7NxFWKEU4rdkP+wAF+EZODCgIAEIEf4ZwbDhiIBCTEiUKGSJwxFWApKZKNGJwY8gb4XBwW5NPko4lKBAMQ6AChVeACSCM2ElnQnsfrxU8W+Qj5UoJnwICMDLS4+CPqBQ4oMQhxIuEgEAIXMQFid7Qj0oAVXQj5NTQQgIyHWLICAgnP0AcXLc1hIBKM6mHSQgLRB2XB8MQuvsDxYQPVnJKXGEEF+ngNnJKXSYUFWQHBKPCwQAIfkEBQAAfwAsAAAAAB4AHQAAB/+Af4KDhIQpKYWJioNtFIWHhUQbi4VqISF6hoiDRCcnGZSEFyEXmoRGJ0ahhG2XbYOQghueRKuipLCbf6iqlG+Fepelf1pasp6ghHaEIyMdhAcXr5Enk4NuJCSES80jv7aDRU3ZTYUd3Vbgf+PZRYov5yPq2Vk/oUHftkVk6v2LYwAB+hMEoGDBP3RQKFTowl8SERAhJlGyUKESf0UiQnQzsKNHWw/kqANhj5IcDiVKgMNiwgQSRS62pCyxZWRLEyAIuZi55c5AJy1VDLpTgoPIQXlWWEiEBUnJQUiEhLKwQmmiHypU5PEHYAWCRV5UdOlHZYWDB4sAZMWizsEKKqERuqhwAo6qg1UCkNCtC27BokAAIfkEBQAAfwAsAAAAAB4AHgAAB/+Af4KDhIQhIYWJioNBQYWHhRgYi4V4IyN4hoiDGCkpk5SDSyNWmoRaKUyhhG+Xb4OQgp2fq4RWI0uwm39MqaE+lZelfwcHgqi0hESEKChhhB1Lr5EpWoQbJyeEdM1yOLXX2SdGhRPNKErgf0biG4of5nTq2UYZoXDA4BvL6v2KOAAB+hOEpWDBPxxKKFTIwV8TEhAhNkm4sETDflkiShzIsWMtKhbUFSETyoKHFQ7AkREhIgmIREcQrEBZRiRLEUUIHZm5AsEWfyDc3Bx0xEGekIOwgBCQ6IeJl4PIJEkSCgiIpYK8rBEEwoQJAP5+gMAiyIEKFYOQmCCpDsDVi2Yl0Q7y2u8q2LJnCZExgQSc1R+E4hICwlcdkEKCCUHtKADJHnWBAAAh+QQFAAB/ACwAAAAAHgAeAAAH/4B/goOEhCMjhYmKgz5whYeFbW2LhWMoKGOGiIMaISEalIRKKAaahBchF6GEYZc4g5CCbZ6Tq4MGKEqwm3+oqpRyhR+XpX8dHYIHnqCEGIQlJQ+sSq+FFEEHhFopKYQc0CXBtoPb3EyFD+Ac439M3Claindb0OzcWs6ULuK2+Oz/ix4IFAhQUIaDB/94WMGQoQeAJyJKPLGw4Yo8AI1MPGGkoMePtgAAYeemSCggP0CAGGeHBIkmZBIJwKISBACSLkm4ISSgJpYSAO00cdlkUAkQP0YO6iLkZiE7IuwQElqUEhYVKpwiifkHqoiV//aoWCMIiwkTg5KIMMnuKhIBZSrPDgIhQgRXW0hU/BhkFu2gIiKSjMOCxAmhvocDs3PKV+5UkH+AmBDCLhAAIfkEBQAAfwAsAAAAAB4AHgAAB/+Af4KDhIQoKIWJioMuLoWHhUFvi4U4JSUBhoiDLyMjL5SEHCUcmoRWI0uhhHKXcoOQgm+ek6uDo6WCsX9LI1ahJYV3l7kTE7KeeIVthA4OVIQPHK+RIx2EByEhhB4rKw4WtoRtb9oXhVQO3nnifxfaIQeKMmXf7eZ6oUfh4m0U7QAXcRg4MKAgDAgR/vkBomHDHwFTSJyYgqFDEBABMqGYgonBjyBt/cDSbsOGUFi8qEAijsiJE0aIJAKyRsXKBSVfnjg5CIBNFWsEBCRiROcgIEi8ACBExgTJQkVIuCG04WWoHyacCkpSRJAbEiTIBBRiQuwfMiJEDGpCIgtArCYnBqFVK8gOWDvtsjJNSygLiSZ5VeylK+jH33ZP5fIlNDUkFhFJ2gUCACH5BAUAAH8ALAAAAAAeAB4AAAf/gH+Cg4SEJSWFiYqDJUeFh4U+OIuFDysrW4aIgx8oKB+UhB4reZqEEyhKoYQWlxaMm384nj6rhHkrHrCDSqmhAoVbl6V/W5l/YZ6ghEGEICAAhFQer5EGYYQdIyOEP88/QLaEb9sjS4UAzyA/4n9L5R2KJVjP7dtWeL/h4m/N7f/yDkEC+EeNQYN/9qhYuHAPwDchIkZ84YXhQi8AL0iMeIGgx48gF2nRsgqJCRPiMKRIwQRDIgBkTpoA0U7LyhQkCckks68dBiY3BwEw4QQLoSIiaBbacGIDIS1AQ9kRkVRQkyyCmJ4gAjCJiCKC7JAgMcjICSP/poow+kcsWUFEI040bUfVziC3hMyitUVGRBJCeAdlkNuOTKHAg5yC/EGiSbtAACH5BAUAAH8ALAAAAAAeAB4AAAf/gH+Cg4SEKyuFiYqDAgKFh4UucouFWyAgHIaIg3clJXeUhD8gWJqEWyWZoYNAl0CDkIJyni6rhFggP7CbfxypoQCFJZelf2Vlgg+eoIQ+hEhIuoMAP6+RHA+EEyh0hE4qKnvFtoJhcigoSoU/SOBd5H9K6ChhikA/KkjwdCgTH6FAgpHDAQeewUWNEh4UhKdhwz9CTEiUKOTgiIsYRyCZKNHJQSsZRyxZSLKkLTtk4B1oE4qMGxEiyFEIEeIChUQgisAUUUQlzRAHCIHYWWSczAs/B/3gmXJQFhJ2EmlJoYVQmxBvQhUhAVWQESOCpqbAcLAJiSyCiJw4MYhJCiYGKbeSkKaWrSAMKajC49oz7VpCbuGeJNGEUF1CeFPAi2r4L6GqJjM4thUIACH5BAUAAH8ALAAAAAAeAB4AAAf/gH+Cg4SEICCFiYqDAECFh4UlFouRKkgChoiDRysrR5SEXipdmYQIKx6ghFgqKliDkIIWnZOqg10qTrCafx4reaCvhAJIo4JYwlSdW4UuhCYmhVhOwoRHHlSEWyUlhEjQQraFD9wlHInQJrriHOUPiyDQ4n/cWwGgANWqcnfz/osAAgb8J2iMQYN/kohYuDDJPxcoIkY0oJChCC7/DEiMqISgx4+23NiZ1+ENKDtNSJAQF2TEiCVBEpHJopKEG5IuR3QgZKdmlh//gizJCYtElpGDjJwgkqhNiAOE3gwFteHEUkFMtAg6ECIEhX9WjQjCkCLFoAshLvireiLD2LKDIJyGaDPP6oZBZM2eTSuOLaG8hPR0ncf0L1xCUEECFhcIACH5BAUAAH8ALAAAAAAeAB4AAAf/gH+Cg4SEKkiFiYqEAIUqKoUCQIuJJiaOkIMlICAllIRIJmSGmYJYID+fhD+WpINAnAKqhE4miIKPgz+onyCFQJajf2trggCcnoTJgiIidqu3kT+Ng2UODoRJzUnCs4JUDisrHoV2zSJc3n8e4g5Uij9FzerheVu93aoWR+r9i1gAAfoThKNgwT9NSChU2MQfhxIQIXJIuJBEFocRJQ7cyHHWhg3qJoT5tMHIiRPefKBAocRHIiImT4L0NmEligmEiJw8YSSDPx9KVtIZpNMIEUJMUmBI9GZEB0I46Lj4pCWFUkEXLgjqMGJEEH9WtQhqEyLEoCUjrPSrevUPWbOCIoJ0faMu7KC3hKyMWOKNLSG8g/B0Vbf0b9lCTzvqCfFCXSAAIfkEBQAAfwAsAAAAAB4AHgAAB/+Af4KDhIQmJoWJioMgP4WHhQAAi5EiIliGiINAKipAlIRJIkWZhF0qXqCEdpZkg5CCAJ2TqoNcIkmvmn9OqKB2hViWpH8gIIJYKkgChcyDJCRuq0mukXtDhADGhE3QTcC1m8aNhW7QJFnhfz/jtIUg5iTqxlgcoGTgtUAl6v2LGQAB+hP0oGDBPycSKjzhz8OKhw89GFl4woi/PBAjDtzIsZYWLeq2yAGlhUmKFOFclCjBwUUiDFpOpgAZbsvKElsIYZCpBYM/FxxuDtrJxOegCyEoJAqDYgIhOUfsUWoTIkQbQUusCJqAAgUcf29CXBAUZMSIQUpQGOh3oKoesmYnB/noikNd1QODyp4dZACFknBUQxDSS+gDCjrqrg6OS8hpRzyMawUCACH5BAUAAH8ALAAAAAAeAB4AAAf/gH+Cg4SEIiKFiYqDdmSFh4lYi4VYJCQ/hoiDACYmAJOETSRZmYRkJkighEWWdoOQglidkqqDWSRNr5p/SCZOoESFP5akf0VFgj+dQIWfgycnG6tNrolCmIM/SKnP0NG1hFhCKiq/hBveRuB/XuRItIUZ6CfrSCpdAsDB4FjM6/+KMAgUCFAQh4MH/6RYyDAFwB8gIkb8waRhCiYAsUicWLCjx1oH2qwrYwFUmwshQoCzsGKFhyOJKKBMeWBkyxVlCFFIGeKAHoBHPLR0MGjnBZGDrIwIkuhBiS2ELHjwAOrNiKWClEwQ5LSEC4BXrQjygQLFIA5P/1kdgWds2UEuJkqUkLPuaodBZM2eLcEBnNUlhPISCiB33ZtCggk9+PhnDB0D6wIBADs=';
	        
	        var inputs = form.getElementsByTagName('button');
	        for (var i = 0; i < inputs.length; i++){
	            var submit = inputs[i];
	            
	            if(submit.type === 'submit') {
	                var ntf = document.createElement("div");
	                ntf.innerHTML = '<center><img src="data:image/png;base64,'+imageBase64+'"><br>'+message+'</center>';
	                submit.style = 'display:none';
	                submit.parentNode.insertBefore(ntf, submit.nextSibling)
	                break;
	            }
	        }
	    }
	    
        document.onreadystatechange = function(){
           if(document.readyState === 'complete'){
                var forms = document.forms;
                for (var i = 0; i < forms.length; i++){
                    forms[i].setAttribute("onSubmit", "lockform(this);");
                };
           }
        }
	</script>

</body></html>
